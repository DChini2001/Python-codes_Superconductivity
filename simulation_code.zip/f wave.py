# -*- coding: utf-8 -*-
"""
Created on Fri Jun 13 23:26:14 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Angular range in k-space (φ from 0 to 2π)
phi = np.linspace(0, 2 * np.pi, 40)

# Theoretical f-wave superconducting gap: |Δ₀ cos(3ϕ)|
delta_f_wave = np.abs(np.cos(3 * phi))

# Simulated experimental data with random noise
simulated_data = delta_f_wave + 0.05 * np.random.normal(size=phi.size)

# Plotting
plt.figure(figsize=(9, 6))
plt.plot(phi, delta_f_wave, label=r'Theoretical f-wave gap: $|\Delta_0 \cos(3\phi)|$', color='maroon', linewidth=2)
plt.scatter(phi, simulated_data, label='Simulated Experimental Data', color='violet', zorder=5)

# Labels and ticks
plt.title('Theoretical f-wave Superconducting Gap vs. Simulated Experimental Data')
plt.xlabel(r'Angle in k-space ($\phi$, radians)')
plt.ylabel(r'Superconducting Gap Magnitude ($|\Delta|$)')
plt.xticks(ticks=[0, np.pi/6, np.pi/3, np.pi/2, 2*np.pi/3, 5*np.pi/6,
                  np.pi, 7*np.pi/6, 4*np.pi/3, 3*np.pi/2, 5*np.pi/3, 11*np.pi/6, 2*np.pi],
           labels=['0', 'π/6', 'π/3', 'π/2', '2π/3', '5π/6', 'π',
                   '7π/6', '4π/3', '3π/2', '5π/3', '11π/6', '2π'])
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
