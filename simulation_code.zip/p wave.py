# -*- coding: utf-8 -*-
"""
Created on Fri Jun 13 23:24:34 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Angular values in k-space (φ from 0 to 2π)
phi = np.linspace(0, 2 * np.pi, 30)

# Theoretical modulated p-wave gap (example function with nodes and modulation)
delta_p_wave = np.abs(0.4 * np.sin(phi) * (1 + 0.6 * np.cos(2 * phi)))

# Simulated experimental data with variation around theoretical curve
simulated_data = delta_p_wave + 0.05 * np.random.normal(size=phi.size)

# Plotting
plt.figure(figsize=(9, 6))
plt.plot(phi, delta_p_wave, label=r'Theoretical modulated p-wave gap: $|\Delta_0 \sin(\phi)(1 + \alpha \cos(2\phi))|$', color='navy', linewidth=2)
plt.scatter(phi, simulated_data, label='Simulated Experimental Data', color='green', zorder=5)

# Formatting
plt.title('Theoretical Modulated p-wave Superconducting Gap vs. Simulated Experimental Data')
plt.xlabel(r'Angle in k-space ($\phi$, radians)')
plt.ylabel(r'Superconducting Gap Magnitude ($|\Delta|$)')
plt.xticks(ticks=[0, np.pi/4, np.pi/2, 3*np.pi/4, np.pi, 5*np.pi/4, 3*np.pi/2, 7*np.pi/4, 2*np.pi],
           labels=['0', 'π/4', 'π/2', '3π/4', 'π', '5π/4', '3π/2', '7π/4', '2π'])
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
