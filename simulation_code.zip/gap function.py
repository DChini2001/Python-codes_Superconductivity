# -*- coding: utf-8 -*-
"""
Created on Fri Jun 13 23:27:13 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Define momentum space grid
kx = np.linspace(-np.pi, np.pi, 300)
ky = np.linspace(-np.pi, np.pi, 300)
KX, KY = np.meshgrid(kx, ky)

# Define chiral p-wave gap function: Δ(k) = Δ₀ (kx + i ky)
# Gap amplitude |Δ(k)| = Δ₀ * sqrt(kx² + ky²), optionally modulated
Delta_0 = 1.0
Delta_k = Delta_0 * np.sqrt(np.sin(KX)**2 + np.sin(KY)**2)

# Plotting
plt.figure(figsize=(6, 5))
contour = plt.contourf(KX, KY, Delta_k, levels=100, cmap='inferno')
cbar = plt.colorbar(contour)
cbar.set_label(r'$|\Delta(\mathbf{k})|$')

plt.title('Chiral p-wave Gap Amplitude in Momentum Space')
plt.xlabel(r'$k_x$')
plt.ylabel(r'$k_y$')
plt.xticks(ticks=[-np.pi, 0, np.pi], labels=[r'$-\pi$', '0', r'$\pi$'])
plt.yticks(ticks=[-np.pi, 0, np.pi], labels=[r'$-\pi$', '0', r'$\pi$'])

plt.tight_layout()
plt.show()
