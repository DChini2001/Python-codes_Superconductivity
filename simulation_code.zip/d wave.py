# -*- coding: utf-8 -*-
"""
Created on Fri Jun 13 23:25:02 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Angular values in k-space (φ from 0 to 2π)
phi = np.linspace(0, 2 * np.pi, 24)

# Theoretical d-wave gap: typically |Δ₀ cos(2ϕ)|
delta_d_wave = np.abs(np.cos(2 * phi))

# Simulated experimental data with noise
simulated_data = delta_d_wave + 0.1 * np.random.normal(size=phi.size)

# Plotting
plt.figure(figsize=(9, 6))
plt.plot(phi, delta_d_wave, label=r'Theoretical d-wave gap: $|\Delta_0 \cos(2\phi)|$', color='blue', linewidth=2)
plt.scatter(phi, simulated_data, label='Simulated Experimental Data', color='red', zorder=5)

# Formatting
plt.title('Theoretical d-wave Superconducting Gap vs. Simulated Experimental Data')
plt.xlabel(r'Angle in k-space ($\phi$, radians)')
plt.ylabel(r'Superconducting Gap Magnitude ($|\Delta|$)')
plt.xticks(ticks=[0, np.pi/4, np.pi/2, 3*np.pi/4, np.pi, 5*np.pi/4, 3*np.pi/2, 7*np.pi/4, 2*np.pi],
           labels=['0', 'π/4', 'π/2', '3π/4', 'π', '5π/4', '3π/2', '7π/4', '2π'])
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
