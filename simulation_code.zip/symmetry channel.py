# -*- coding: utf-8 -*-
"""
Created on Fri Jun 13 23:23:14 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Simulated dominant eigenvalues (λ) for different symmetry channels
symmetry_channels = ['s-wave', 'd-wave', 'p-wave', 'f-wave', 'extended s-wave']
eigenvalues = [0.85, 1.20, 1.35, 0.65, 1.10]  # Customize if needed

# Create the bar chart
plt.figure(figsize=(8, 5))
bars = plt.bar(symmetry_channels, eigenvalues, color='teal')

# Axis labels and title
plt.xlabel('Symmetry Channel')
plt.ylabel('Dominant Eigenvalue (λ)')
plt.title('Symmetry-Selective Pairing Strength in Unconventional Superconductivity Model')

# Draw a horizontal line at λ = 1 (pairing threshold)
plt.axhline(y=1.0, color='gray', linestyle='--', linewidth=1, label='Critical λ = 1 (Pairing Threshold)')
plt.legend()

# Highlight the maximum eigenvalue (dominant pairing channel)
max_index = np.argmax(eigenvalues)
bars[max_index].set_color('darkred')  # Emphasize strongest pairing

# Add grid and layout adjustments
plt.grid(axis='y', linestyle=':', alpha=0.6)
plt.tight_layout()

# Show the plot
plt.show()
